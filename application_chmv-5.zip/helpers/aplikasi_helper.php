<?php

function menu($menu, $blnReturn = false) {
    $out = '<ul class="nav" id="side-menu">';
    foreach ($menu as $menu_kelompok => $menu_item) {
        if (is_array($menu_item)) {
            $out .= '<li>';
            $out .= '<a href="#"><i class="fa  fa-book  fa-fw"></i>' . $menu_kelompok . '<span class="fa arrow"></span></a>';
            //$out .= '<a href="#">' . $menu_kelompok . '</a>';
            $out .= '<ul class="nav nav-second-level">';
            foreach ($menu_item as $menu_judul => $menu_link) {
                $out .= '<li><a href="' . base_url() . $menu_link . '">' . $menu_judul . '</a></li>';
            }
            $out .= '</ul>';
            $out .= '</li>';
        } else {
            $out .= '<li>';
            //$out .= '<a href="' . base_url() . $menu_item . '">' . $menu_kelompok . '</a>';
            $out .= '<a href="' . base_url() . $menu_item . '"><i class="fa fa-files-o fa-fw"></i>' . $menu_kelompok . '</a>';
            $out .= '</li>';
        }
    }
    $out .= '</ul>';

    if ($blnReturn) {
        return $out;
    } else {
        echo $out;
    }
}

function topmenu($menu, $blnReturn = false) {
    $out = '<ul class="nav navbar-top-links navbar-right">';
    foreach ($menu as $menu_kelompok => $menu_item) {
        if (is_array($menu_item)) {
            $out .= '<li class="dropdown">';
            $out .= '<a class="dropdown-toggle" data-toggle="dropdown" href="#">' . $menu_kelompok . '</a>';
            $out .= '<ul class="dropdown-menu dropdown-messages">';
            foreach ($menu_item as $menu_judul => $menu_link) {
                if ($menu_link == 'Logout') {
                    $out .= '<li class="divider">.</li>';
                }
                $out .= '<li><a href="' . base_url() . $menu_link . '">' . $menu_judul . '</a></li>';
            }
            $out .= '</ul>';
            $out .= '</li>';
        } else {
            $out .= '<li>';
            //$out .= '<a href="' . base_url() . $menu_item . '">' . $menu_kelompok . '</a>';
            $out .= '<a href="' . base_url() . $menu_item . '">' . $menu_kelompok . '</a>';
            $out .= '</li>';
        }
    }
    $out .= '</ul>';

    if ($blnReturn) {
        return $out;
    } else {
        echo $out;
    }
}

function checkDateTime($data) {
    if (date('Y-m-d H:i:s', strtotime($data)) == $data) {
        return true;
    } else {
        return false;
    }
}

function hitung_umur($tanggal_lahir) {
    $birthDate = new DateTime($tanggal_lahir);
    $today = new DateTime("today");
    if ($birthDate > $today) {
        exit("0 tahun 0 bulan 0 hari");
    }
    $y = $today->diff($birthDate)->y;
    $m = $today->diff($birthDate)->m;
    $d = $today->diff($birthDate)->d;
    return $y . "Th " . $m . "Bl " . $d . "Hr ";
}

function fHitStandart($idpas = '', $peny = null, $bln = '', $thn = '') {
    $ci = & get_instance();
    $ci->db->select('count(c.id) as org', false);
    $ci->db->from('tb_pemeriksaan c');
    $ci->db->join('tb_pasien p', 'c.id_pasien = p.id', 'left');
    if ($idpas != '') {
        $ci->db->where("p.id", $idpas);
    }
    if ($peny != '') {
        $ci->db->like('c.id_penyakit', $peny, 'both');
    }
    if ($thn != '') {
        $ci->db->where("YEAR(c.tgl_periksa)", $thn);
    }
    if ($bln != '') {
        $ci->db->where("MONTH(c.tgl_periksa)", $bln);
    }
    $ci->db->group_by(array("c.id_pasien", "YEAR(c.tgl_periksa)", "MONTH(c.tgl_periksa)"));
    $dbres = $ci->db->get()->row();
    $count = $dbres ? $dbres->org : 0;
    return $count;
}

function fJpasienPenyBlnThn($peny = '', $bln = '', $thn = '') {
    $ci = & get_instance();
    $ci->db->select('count(c.id) as org', false);
    $ci->db->from('tb_pemeriksaan c');
    $ci->db->join('tb_pasien p', 'c.id_pasien = p.id', 'left');
    if (fUser('usrrole') == 'users') {
        $ci->db->where("p.id_unor", fUser('usrunit'));
    }
    if ($peny != '') {
        $ci->db->like('c.id_penyakit', $peny, 'both');
    }
    $ci->db->where("YEAR(c.tgl_periksa)", $thn);
    $ci->db->where("MONTH(c.tgl_periksa)", $bln);
//    $ci->db->order_by("mag_year", "desc"); 
    $ci->db->group_by(array("YEAR(c.tgl_periksa)", "MONTH(c.tgl_periksa)"));
    $dbres = $ci->db->get()->row();
    $count = $dbres ? $dbres->org : 0;
    return $count;
}

function f_jml_pasien_year($pkm = '', $peny = '', $tahun = '') {
    $CI = &get_instance();
    $CI->db->select('ps.id');
    $CI->db->from('tb_pasien ps');
    $CI->db->join('tb_pemeriksaan p', 'ps.id = p.id_pasien', 'left');
    if (fUser('usrrole') == 'users') {
        $CI->db->where("ps.id_unor", fUser('usrunit'));
    }
    if ($peny != '') {
        $CI->db->like('p.id_penyakit', $peny, 'both');
    }
    if ($tahun != '') {
        $CI->db->like('year(p.tgl_periksa)', $tahun);
    }
    $CI->db->group_by('p.id_pasien');
    $dbres = $CI->db->get();
    if ($dbres) {
        return $dbres->num_rows();
    } else {
        return 0;
    }
}

function f_hit_pasien($pkm = '', $peny = '', $tahun = '', $bulan = '') {
    $ci = &get_instance();
    $ci->db->select('count(ps.id) jml');
    $ci->db->from('tb_pasien ps');
    $ci->db->join('tb_pemeriksaan p', 'ps.id = p.id_pasien', 'left');

//    if (fUser('usrrole') == 'users') {
//        $ci->db->where("ps.id_unor", fUser('usrunit'));
//    }

    if ($pkm != '') {
        $ci->db->where('ps.id_unor', $pkm);
    }

    if ($peny != '') {
        $ci->db->like('p.id_penyakit', $peny, 'both');
    }

    if ($tahun != '') {
        $ci->db->where('YEAR(p.tgl_periksa)', $tahun);
    }
    if ($bulan != '') {
        $ci->db->where('MONTH(p.tgl_periksa)', $bulan);
    }

    $ci->db->group_by(array("p.id_pasien", "YEAR(p.tgl_periksa)", "MONTH(p.tgl_periksa)"));
    $dbres = $ci->db->get();
    if ($dbres) {
        return $dbres->num_rows();
    } else {
        return 0;
    }
}

function f_jml_unor() {
    $CI = &get_instance();
    $CI->db->select('id');
    $CI->db->from('tbl_unitorg');
    $dbres = $CI->db->get();
    if ($dbres->num_rows() > 0) {
        return $dbres->num_rows();
    } else {
        return '0';
    }
}

function tgl($vtgl) {
    if (date('Y-m-d H:i:s', strtotime($vtgl)) == $vtgl) {
        $vartg = date('d-m-Y', strtotime($vtgl));
        list( $tgl, $bll, $thl) = explode("-", $vartg);
        $res_tgl = $tgl . '-' . $bll . '-' . $thl;
        return $res_tgl;
    } else {
        return '00-00-0000';
    }

    //$vartg = date('d-m-Y', strtotime($vtgl));
    //list( $tgl, $bll, $thl) = explode("-", $vartg);
    //$res_tgl = $tgl . '-' . $bll . '-' . $thl;
    //return $res_tgl;
}

function post_tgl($vtgl) {
    //$vartg = date('d-m-Y', strtotime($vtgl));
    list( $bll, $tgl, $thl) = explode("/", $vtgl);
    $res_tgl = $thl . '-' . $bll . '-' . $tgl;
    return $res_tgl;
}

function tempel($tabel, $hasilcari, $kondisi = null) {
    $res_cari = mysql_query("SELECT * FROM $tabel WHERE $kondisi");
    if ($res_cari) {
        if ($row_cari = mysql_fetch_array($res_cari)) {
            return $row_cari[$hasilcari];
        }
    } else {
        return '-- no data result --';
    }
}

function fLastVisit($idpas = '') {
//PERTAMA TERAKHHIR KUNUNGAN
    $ci = & get_instance();
    $query = $ci->db->query("SELECT tgl_periksa "
            . "FROM tb_pemeriksaan "
            . "WHERE id_pasien='$idpas' "
            . "ORDER BY tgl_periksa DESC");

    if ($query->num_rows() >= 1) {
        $tmp = $query->row_array();
        if (!next($tmp)) {
            return $tmp['tgl_periksa'];
        }
    } else {
        return '---';
    }
    //echo reset($arr); 
}

function fKetemu($idpas = '', $idpen = '') {
//PERTAMA KALI DI KETEMUAN PENYAKIT
    $ci = & get_instance();
    $query = $ci->db->query("SELECT tgl_periksa "
            . "FROM tb_pemeriksaan "
            . "WHERE id_pasien='$idpas' "
            . "AND id_penyakit LIKE '%$idpen%'"
            . "ORDER BY tgl_periksa ASC");

    if ($query->num_rows() >= 1) {
        $tmp = $query->row_array();
//        return $query['tgl_periksa'];
        if ($query->num_rows() > 1) {
            $tmp2 = reset($tmp);
            return $tmp2;
        } else {
            return $tmp['tgl_periksa'];
        }
    } else {
        return '---';
    }
    //echo reset($arr); 
}

//function fListRiwayatPenyakit($idpas = '') {
//    $ci = & get_instance();
//    $ci->db->select('id_pasien, id_penyakit, tgl_periksa');
//    $ci->db->from('tb_pemeriksaan');
//    $ci->db->where('id_pasien', $idpas);
//    $ci->db->group_by(array("id_penyakit"));
//    $query = $ci->db->get();
//    if ($query) {
//        return $query;
//    } else {
//        return 0;
//    }
//}

function fNamaPasien($idx = '') {
    $ci = & get_instance();
    $query = $ci->db->query("SELECT pasien_nama FROM tb_pasien where id='$idx'");
    if ($query->num_rows() >= 1) {
        $tmp = $query->row_array();
        return $tmp['pasien_nama'];
    } else {
        return '-- data tidak diketemukan --';
    }
}

function fTarget($pkm = '', $thn = '', $peny = '') {
    $ci = & get_instance();
    $query = $ci->db->query("SELECT * FROM tbl_pkmtarget "
            . "where idunit='$pkm' "
            . "and tahun = '$thn'"
            . "and idpeny = '$peny'");
    if ($query) {
        return $query;
    } else {
        return 0;
    }
}

function fTbUnor($idx = '') {
    $ci = & get_instance();
    if ($idx != '') {
        $query = $ci->db->query("SELECT unor_name FROM tbl_unitorg where id='$idx'");
        if ($query->num_rows() >= 1) {
            $tmp = $query->row_array();
            return $tmp['unor_name'];
        } else {
            return '-- data tidak diketemukan';
        }
    } else {
        $query = $ci->db->query("SELECT * FROM tbl_unitorg");
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return '-- data tidak diketemukan';
        }
    }
}

function fTbPenyakit($idx = '') {
    $ci = & get_instance();
    if ($idx != '') {
        $query = $ci->db->query("SELECT penyakit_nama FROM tbl_penyakit where id='$idx'");
        if ($query->num_rows() >= 1) {
            $tmp = $query->row_array();
            return $tmp['penyakit_nama'];
        } else {
            return '---';
        }
    } else {
        $query = $ci->db->query("SELECT * FROM tbl_penyakit");
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return '---';
        }
    }
}

function fTbObat($idx = '') {
    $ci = & get_instance();
    if ($idx != '') {
        $query = $ci->db->query("SELECT obat_nama FROM tbl_obat where id='$idx'");
        if ($query->num_rows() >= 1) {
            $tmp = $query->row_array();
            return $tmp['obat_nama'];
        } else {
            return '---';
        }
    } else {
        $query = $ci->db->query("SELECT * FROM tbl_obat");
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return '---';
        }
    }
}

function fTbDokter($idx = '') {
    $ci = & get_instance();
    if ($idx != '') {
        $query = $ci->db->query("SELECT nama_dokpera FROM tbl_dokterperawat where id='$idx'");
        if ($query->num_rows() >= 1) {
            $tmp = $query->row_array();
            return $tmp['nama_dokpera'];
        } else {
            return '---';
        }
    } else {
        $query = $ci->db->query("SELECT * FROM tbl_dokterperawat");
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return '---';
        }
    }
}

function fhit_stbulan($pkm = '', $peny = '', $thn = '', $bln = '') {
    $today = date('Y-m', time());
    $birth = date('Y-m', strtotime($thn . '-' . $bln));
    if ($birth > $today) {
        return 0;
    } else {
        $ci = & get_instance();
        $ci->db->select('count(p.id) as org', false);
        $ci->db->from('tb_pemeriksaan p');
        if ($pkm != '') {
            $ci->db->join('tb_pasien ps', 'p.id_pasien = ps.id', 'left');
            $ci->db->where('ps.id_unor', $pkm);
        }
        if ($peny != '') {
            $ci->db->like('p.id_penyakit', $peny, 'both');
        }
        $ci->db->where("YEAR(p.tgl_periksa)", $thn);
        $ci->db->where("MONTH(p.tgl_periksa)", $bln);
        $ci->db->group_by(array("p.id_pasien", "YEAR(p.tgl_periksa)", "MONTH(p.tgl_periksa)"));
        $dbres = $ci->db->get()->row();

        $count = $dbres ? $dbres->org : 0;
        return $count;
    }
}

function f_get_bulan($data = null) {
    $blpan = array(
        '01' => 'JANUARI',
        '02' => 'FEBRUARI',
        '03' => 'MARET',
        '04' => 'APRIL',
        '05' => 'MEI',
        '06' => 'JUNI',
        '07' => 'JULI',
        '08' => 'AGUSTUS',
        '09' => 'SEPTEMBER',
        '10' => 'OKTOBER',
        '11' => 'NOVEMBER',
        '12' => 'DESEMBER'
    );
    if ($data != NULL) {
        return element($data, $blpan);
    } else {
        return $blpan;
    }
}

function fshortbln($data = null) {
    $blpan = array(
        '01' => 'JAN',
        '02' => 'FEB',
        '03' => 'MAR',
        '04' => 'APR',
        '05' => 'MEI',
        '06' => 'JUN',
        '07' => 'JUL',
        '08' => 'AGU',
        '09' => 'SEP',
        '10' => 'OKT',
        '11' => 'NOV',
        '12' => 'DES'
    );
    if ($data != NULL) {
        return element($data, $blpan);
    } else {
        return $blpan;
    }
}

function hitung_waktu($time1 = null, $time2 = null) {
    $timezone = "Singapore";
    date_default_timezone_set($timezone);
    $time1_unix = strtotime(date('Y-m-d') . ' ' . $time1 . ':00');
    $time2_unix = strtotime(date('Y-m-d') . ' ' . $time2 . ':00');
    $begin_day_unix = strtotime(date('Y-m-d') . ' 00:00:00');
    $jumlah_time = date('H:i', ($time1_unix + ($time2_unix - $begin_day_unix)));
    return $jumlah_time;
}

function f_jam() {
    $jamlist = array(
        '00' => '00',
        '01' => '01',
        '02' => '02',
        '03' => '03',
        '04' => '04',
        '05' => '05',
        '06' => '06',
        '07' => '07',
        '08' => '08',
        '09' => '09',
        '10' => '10',
        '11' => '11',
        '12' => '12',
        '13' => '13',
        '14' => '14',
        '15' => '15',
        '16' => '16',
        '17' => '17',
        '18' => '18',
        '19' => '19',
        '20' => '20',
        '21' => '21',
        '22' => '22',
        '23' => '23'
    );
    return $jamlist;
}

function terbilang($satuan) {
    $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    if ($satuan < 12)
        return " " . $huruf[$satuan];
    elseif ($satuan < 20)
        return Terbilang($satuan - 10) . " belas";
    elseif ($satuan < 100)
        return Terbilang($satuan / 10) . " puluh" .
                Terbilang($satuan % 10);
    elseif ($satuan < 200)
        return "seratus" . Terbilang($satuan - 100);
    elseif ($satuan < 1000)
        return Terbilang($satuan / 100) . " ratus" .
                Terbilang($satuan % 100);
    elseif ($satuan < 2000)
        return "seribu" . Terbilang($satuan - 1000);
    elseif ($satuan < 1000000)
        return Terbilang($satuan / 1000) . " ribu" .
                Terbilang($satuan % 1000);
    elseif ($satuan < 1000000000)
        return Terbilang($satuan / 1000000) . " juta" .
                Terbilang($satuan % 1000000);
    elseif ($satuan >= 1000000000)
        echo "Angka terlalu Besar";
}

function seo_title($s) {
    $c = array(' ');
    $d = array('-', '/', '\\', ',', '.', '#', ':', ';', '\'', '"', '[', ']', '{', '}', ')', '(', '|', '`', '~', '!', '@', '%', '$', '^', '&', '*', '=', '?', '+', '–');
    $s = str_replace($d, '', $s); // Hilangkan karakter yang telah disebutkan di array $d
    $s = strtolower(str_replace($c, '_', $s)); // Ganti spasi dengan tanda - dan ubah hurufnya menjadi kecil semua
    return $s;
}

// Function to get the client IP address
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function fUser($usr = '') {
    $ci = &get_instance();
    $session = $ci->session->userdata('logged_user');
    if ($session != '') {
        return $session[$usr];
    }
}

?>
