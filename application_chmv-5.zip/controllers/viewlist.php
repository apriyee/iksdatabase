<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Viewlist extends CI_Controller {

    public function __construct() {
        parent::__construct();
//        if (fUser('usrrole') == '') {
//            redirect(base_url());
//        }
    }

    public function index() {
        $this->template->load('template/general_temp', 'welcome_message');
    }

    function rekperorg($idpkm = '') {
        $dt['judul'] = 'STANDART PELAYANAN MINIMAL ' . strtoupper(fTbUnor($idpkm));
        $dt['idpkm'] = $idpkm;
        $this->template->load('template/general_temp', 'pages/rekap_view_pkm_allpeny', $dt);
    }

    function unitorg() {
        if (fUser('usrrole') == 'users') {
            $dt['judul'] = 'STANDART PELAYANAN MINIMAL';
            $this->template->load('template/general_temp', 'pages/rekap_view_pasien_org', $dt);
        } else {
            $dt['judul'] = 'Pasien Menurut Unit Organisasi';
            $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_unitorg");
            $this->template->load('template/general_temp', 'pages/view_list_unor', $dt);
        }
    }

    function pasien($idx = '') {
        $this->load->model('model_view_list');
        if (fUser('usrrole') != '') {
            $dt['idpeny'] = $idx;
            if (fUser('usrrole') == 'users') {
                $unit = fUser('usrunit');
                $dt['judul'] = 'Register Pasien ' . fTbPenyakit($idx) . '<br>' . fTbUnor($unit);
                $dt['dtlist'] = $this->model_view_list->view_pasien($unit, $idx);
            } else {
                $dt['judul'] = 'Register Pasien ' . fTbPenyakit($idx);
                $dt['dtlist'] = $this->model_view_list->view_pasien("", $idx);
            }
            $this->template->load('template/general_temp', 'pages/list_view_pasien', $dt);
        } else {
            $dt['judul'] = 'STANDART PELAYANAN MINIMAL';
            $dt['idpeny'] = $idx;
            $this->template->load('template/general_temp', 'pages/rekap_view_pasien', $dt);
        }
    }

}
