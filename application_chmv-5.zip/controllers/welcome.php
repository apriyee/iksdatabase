<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function index() {
        $this->template->load('template/general_temp', 'welcome_message');
    }

    function caripasien() {
        if (strlen($this->db->escape_str($this->input->post('entername'))) > 2) {
            $cari = $this->db->escape_str($this->input->post('entername'));
            if (fUser('usrrole') == "") {
                echo '<script>alert("Maaf, Anda tidak diperkenankan untuk mencari pasien., '
                . 'silahkan hubungi operator atau admin anda."); window.location.href = "' . base_url() . '";</script>';
            } else {
                if (is_numeric($cari)) {
                    $this->db->select('*');
                    $this->db->from('tb_pasien');
                    $this->db->like('nik', $cari);
                } else {
                    $this->db->select('*');
                    $this->db->from('tb_pasien');
                    $this->db->like('pasien_nama', $cari);
                }
                $dt['dtlist'] = $this->db->get();
                $this->template->load('template/general_temp', 'pages/cari_pasien_list', $dt);
            }
        } else {
            echo '<script>alert("Maaf, dalam pencarian paling tidak ada unsur kata atau nik, '
            . 'Perlu bantuan silahkan hubungi operator atau admin anda."); window.location.href = "' . base_url() . '";</script>';
        }
    }

    function loginpages() {
        if ($this->input->post()) {
//            echo json_encode($this->input->post());
            $this->form_validation->set_rules('usr_name', 'usr_name', 'trim|required');
            $this->form_validation->set_rules('usr_passw', 'usr_passw', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                echo '<script>alert("Username atau password tidak dikenal");</script>';
            } else {
                $username = seo_title($this->input->post('usr_name'));
                $password = md5($this->input->post('usr_passw'));
                $query = $this->db->query("SELECT * FROM tbl_pengguna WHERE usr_name='$username' and usr_passw='$password' LIMIT 1");
                if ($query->num_rows() > 0) {
                    $row = $query->row();
                    $data_user['usrid'] = $row->id;
                    $data_user['usrname'] = $row->usr_name;
                    $data_user['usrpass'] = $row->usr_passw;
                    $data_user['usrnama'] = $row->usr_fullname;
                    $data_user['usrrole'] = $row->usr_roles;
                    $data_user['usrunit'] = $row->usr_unit;
                    $this->waktu_login($row->id);
                    $this->session->set_userdata('logged_user', $data_user);
                    redirect(base_url());
                } else {
                    echo '<script>alert("Username atau password tidak diketemukan");</script>';
                }
            }
        }
        $dt['aksi_url'] = base_url() . 'index.php/welcome/loginpages';
        $this->template->load('template/general_temp', 'login_pages', $dt);
    }

    function waktu_login($id) {
        $dt = date('Y-m-d h:i:s', time());
        $sql_db = "update tbl_pengguna set last_login = '$dt' where id='$id'";
        return $this->db->query($sql_db);
    }

    function userlogout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'index.php/welcome');
    }

}
