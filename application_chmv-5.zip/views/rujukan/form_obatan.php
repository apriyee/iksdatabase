<?php
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$usr_fullname = isset($dtEdit) ? $rows->obat_nama : '';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama Obatan</label>
                                <input class="form-control" name="obat_nama" id="obat_nama"
                                       autocomplete="off"
                                       value="<?= $usr_fullname; ?>">
                                <p class="help-block">Isikan Nama obatan.</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>