<?php
$thn = $this->input->post('tahun') ? $this->input->post('tahun') : date('Y', time());
?>
<!-- /.row -->
<p>&nbsp;</p>
<div class="row">
    <div class="col-lg-3">
        <form role="form" method="POST">
            <div class="form-group input-group">
                <span class="input-group-addon">Tahun</span>
                <input type="text" class="form-control" name="tahun" value="<?= $thn; ?>">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button" onclick="this.form.submit()">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-group fa-fw"></i> <?= $judul; ?></b>
                <div class="pull-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" onclick="printDiv('printArea')">Cetak</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="row" id="printArea">
                    <div class="col-lg-12">
                        <h3><?= $judul; ?></h3>
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered table-hover" id="dataTables">
                                <thead>
                                    <tr>
                                        <th rowspan="3">No.</th>
                                        <th rowspan="3" valign="middle">Nama Unit Organisasi</th>
                                        <th colspan="<?= fTbPenyakit()->num_rows() * 3; ?>"
                                            style="text-align: center;">Target dan Realisasi  Tahun <?= $thn; ?></th>
                                        <th rowspan="3" style="text-align: center;">Jumlah<br>Pasien</th>
                                    </tr>
                                    <tr>
                                        <?php
                                        foreach (fTbPenyakit()->result() as $h) {
                                            ?>
                                            <th colspan="<?= fTbPenyakit()->num_rows(); ?>" style="text-align: center;"><?= $h->sort_name; ?></th>
                                        <?php } ?>
                                    </tr>
                                    <tr>
                                        <?php
                                        foreach (fTbPenyakit()->result() as $h) {
                                            ?>
                                            <th style="text-align: center;">T</th>
                                            <th style="text-align: center;">R</th>
                                            <th style="text-align: center;">%</th>
                                        <?php } ?>
                                    </tr>

                                </thead>
                                <tbody>
                                    <?php
                                    if ($dtlist->num_rows() >= 1) {
                                        $urut = 0;
                                        foreach ($dtlist->result() as $xdt) {
                                            $urut++;
                                            ?>
                                            <tr class="odd gradeX">
                                                <td><?= $urut; ?></td>
                                                <td><?= $xdt->unor_name; ?></td>
                                                <?php
                                                $persen = 0;
                                                foreach (fTbPenyakit()->result() as $h) {
                                                    $target = fTarget($xdt->id, $thn, $h->id);
                                                    $ntarget = $target->result() ? $target->row()->target : '-';
                                                    $real = f_hit_pasien($xdt->id, $h->id, $thn, "");
                                                    $nreal = $real >= 1 ? $real : '-';
                                                    $pas = f_hit_pasien($xdt->id, "", $thn, "");
                                                    $npas = $pas >= 1 ? $pas : '-';
                                                    
                                                    if(is_numeric($nreal) && is_numeric($ntarget)) {
                                                        $persen = ($nreal/$ntarget)*100;
                                                    }
                                                    ?>
                                                    <td style="text-align: center;"><?= $ntarget; ?></td>
                                                    <td style="text-align: center;"><?= $nreal; ?></td>
                                                    <td style="text-align: center;"><?= $persen > 0 ? number_format($persen,2) : $persen; ?></td>
                                                <?php } ?>
                                                <td style="text-align: center;"><?= $npas; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<script>
//    $(document).ready(function () {
//        $('#dataTables').DataTable({
//            responsive: true
//        });
//    });
</script>
