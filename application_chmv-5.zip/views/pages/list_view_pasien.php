<h1><?= APPNAME; ?></h1>
<?php
$thn = $this->input->post('tahun') ? $this->input->post('tahun') : date('Y', time());
?>
<div class="row">
    <div class="col-lg-3">
        <form role="form" method="POST">
            <div class="form-group input-group">
                <span class="input-group-addon">Tahun</span>
                <input type="text" class="form-control" name="tahun" value="<?= $thn; ?>">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button" onclick="this.form.submit()">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-group fa-fw"></i> <?= $judul; ?></b>
                <div class="pull-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" onclick="printDiv('printArea')">Cetak</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="row" id="printArea">
                    <div class="col-lg-12">
                        <h3><?= $judul; ?> Tahun <?= $thn; ?></h3>
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered"  style="font-size: 0.8em;">
                                <thead>
                                    <tr>
                                        <th rowspan="2">Nama</th>
                                        <th rowspan="2">NIK</th>
                                        <th rowspan="2">Tempat Tgl. Lahir<br>Umur</th>
                                        <th rowspan="2">Alamat</th>
                                        <th rowspan="2">Awal Kontak</th>
                                        <th rowspan="2">No. BPJS</th>
                                        <th colspan="12" style="text-align: center;">PEMANTAUAN</th>
                                    </tr>
                                    <tr>
                                        <?php foreach (fshortbln() as $ix => $sbln) { ?>
                                            <th><?= $sbln; ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($dtlist->num_rows() > 0) {
                                        foreach ($dtlist->result() as $xdt) {
                                            $hari = date('d', time());
                                            $ketemu = fKetemu($xdt->id, $idpeny);
                                            ?>
                                            <tr class="odd gradeX">
                                                <td><?= $xdt->pasien_nama; ?></td>
                                                <td><?= $xdt->nik; ?></td>
                                                <td><?= $xdt->tmp_lahir; ?>/ <?= date('d-m-Y', strtotime($xdt->tgl_lahir)); ?>
                                                    <br><?= hitung_umur($xdt->tgl_lahir); ?></td>
                                                <td><?= $xdt->alamat; ?></td>
                                                <td><?= tgl($ketemu); ?></td>
                                                <td><?= $xdt->nomor_bpjs; ?></td>
                                                <?php
                                                $tg1 = date('Y-m-d', strtotime($ketemu));
                                                foreach (fshortbln() as $ix => $sbln) {
                                                    $hitstd = $thn . '-' . $ix . '-' . $hari;
                                                    $tg2 = date('Y-m-d', strtotime($hitstd));
                                                    $harini = date('Y-m-d', time());

                                                    if ($hitstd < $tg1) {
                                                        $std = '-';
                                                    } elseif ($hitstd > $harini) {
                                                        $std = '-';
                                                    } else {
                                                        $xstd = fHitStandart($xdt->id, $idpeny, $ix, $thn);
                                                        if($xstd != '0') {
                                                            $std = '<i class="fa fa-check"></i>';
                                                        } else {
                                                            $std = '<i class="fa fa-times" style="color:red"></i>';
                                                        }
                                                    }
//                                                    $std = fHitStandart($idpas = '', $peny = null, $bln = '', $thn = '');
                                                    // fa-check fa-times
                                                    ?>
                                                    <td><?= $std; ?></td>
                                                <?php } ?>
                                            </tr>
                                                <?php
                                            }
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
//    $(document).ready(function () {
//        $('#dataTables').DataTable({
//            responsive: true
//        });
//    });
</script>
