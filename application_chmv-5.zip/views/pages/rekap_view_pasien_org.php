<h1><?= APPNAME; ?></h1>
<?php
$thn = $this->input->post('tahun') ? $this->input->post('tahun') : date('Y', time());
$unit = fUser('usrunit');
?>
<div class="row">
    <div class="col-lg-3">
        <form role="form" method="POST">
            <div class="form-group input-group">
                <span class="input-group-addon">Tahun</span>
                <input type="text" class="form-control" name="tahun" value="<?= $thn; ?>">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button" onclick="this.form.submit()">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><i class="fa fa-group fa-fw"></i> <?= $judul; ?>
                <div class="pull-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" onclick="printDiv('printArea')">Cetak</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="row" id="printArea">
                    <div class="col-lg-12">
                        <h4>
                            <?= $judul; ?>
                            <br><?= fTbUnor($unit); ?>
                            <br>TAHUN <?= $thn; ?>
                        </h4>
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th rowspan="2">NO</th>
                                        <th rowspan="2">BULAN</th>
                                        <?php
                                        foreach (fTbPenyakit()->result() as $hpy) {
                                            ?>
                                            <th colspan="2" style="text-align: center;"><?= fTbPenyakit($hpy->id) ?></th>
                                            <?php
                                        }
                                        ?>
                                        <th rowspan="2" style="text-align: center;">JUMLAH<br>PASIEN</th>
                                    </tr>
                                    <tr>
                                        <?php
                                        foreach (fTbPenyakit()->result() as $py) {
                                            ?>
                                            <th style="text-align: center;">ST</th>
                                            <th style="text-align: center;">TST</th>
                                            <?php
                                        }
                                        ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
//                                    $hit_pasien = f_jml_pasien_year("", $idpeny, $thn);
                                    $today = date('Y-m', time());
                                    foreach (f_get_bulan() as $idbln => $nbln) {
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?= $idbln; ?></td>
                                            <td><?= $nbln; ?></td>
                                            <?php
                                            foreach (fTbPenyakit()->result() as $bpy) {
                                                $idpeny = $bpy->id;
                                                $hit_pasien = f_hit_pasien($unit, $idpeny, $thn, $idbln);
                                                $std = fhit_stbulan($unit, $idpeny, $thn, $idbln);
                                                $birth = date('Y-m', strtotime($thn . '-' . $idbln));
                                                if ($birth > $today) {
                                                    $ts = 0;
                                                    $jml_pas = 0;
                                                } else {
                                                    $jml_pas = $hit_pasien > 0 ? $hit_pasien : 0;
                                                    $ts = $jml_pas - $std;
                                                }
                                                ?>
                                                <td  style="text-align: center;"><?= $std > 0 ? $std : '-' ?></td>
                                                <td  style="text-align: center;"><?= $ts > 0 ? $ts : '-' ?></td>
                                            <?php } ?>
                                            <td  style="text-align: center;"><?= $jml_pas; ?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#dataTables').DataTable({
            responsive: true
        });
    });
</script>
