<h1 class="page-header">Otoritas Pengguna </h1>
<div class="col-md-5">
    <div class="login-panel panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Please Sign In</h3>
        </div>
        <div class="panel-body">
            <form role="form" method="post" action="<?= $aksi_url; ?>"
                  id="theForm">
                <fieldset>
                    <div class="form-group">
                        <input class="form-control" placeholder="E-mail" name="usr_name" type="text" autofocus>
                    </div>
                    <div class="form-group">
                        <input class="form-control" placeholder="Password" name="usr_passw" type="password" value="">
                    </div>
                    <!-- Change this to a button or input when using this as a form -->
                    <a href="javascript:void(0)" 
                       class="btn btn-lg btn-success btn-block" onclick="submitForm();">Login</a>
                </fieldset>
            </form>
        </div>
    </div>
</div>
<script>
    function submitForm()
    {
        document.getElementById("theForm").submit();
    }


</script>
