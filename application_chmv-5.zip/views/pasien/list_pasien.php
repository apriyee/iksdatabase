<h1><?= APPNAME; ?>!</h1>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-group fa-fw"></i> <?= $judul; ?></b>
                <div class="pull-right">
                    <a href="<?= $tambah; ?>">
                        <button type="button" class="btn btn-primary btn-xs">
                            <i class="fa fa-plus fa-fw"></i> Data Pasien Baru
                        </button>
                    </a>
                </div>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered table-hover" id="dataTables">
                                <thead>
                                    <tr>
                                        <th>Opsi</th>
                                        <th>Nama</th>
                                        <th>NIK</th>
                                        <th>Tempat<br>Tgl. Lahir</th>
                                        <th>Umur</th>
                                        <th>Pemeriksaan<br>terakhir.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($dtlist->num_rows() >= 1) {
                                        foreach ($dtlist->result() as $xdt) {
                                            ?>
                                            <tr class="odd gradeX">
                                                <td class="center-block">
                                                    <a href="<?= $hapus; ?><?= $xdt->id; ?>" 
                                                       onclick="return confirm('Yakin data akan diHapus?')">
                                                        <button type="button" class="btn btn-danger btn-xs">Hapus</button>
                                                    </a>
                                                    <a href="<?= $edit; ?><?= $xdt->id; ?>">
                                                        <button type="button" class="btn btn-success btn-xs">Edit</button>
                                                    </a>
                                                </td>
                                                <td><a href="<?= base_url(); ?>index.php/pasien/periksa/<?= $xdt->id; ?>"><?= $xdt->pasien_nama; ?></a></td>
                                                <td><a href="<?= base_url(); ?>index.php/pasien/periksa/<?= $xdt->id; ?>"><?= $xdt->nik; ?></a></td>
                                                <td><?= $xdt->tmp_lahir; ?>/ <?= date('d-m-Y', strtotime($xdt->tgl_lahir)); ?></td>
                                                <td><?= hitung_umur($xdt->tgl_lahir); ?></td>
                                                <td><?= fLastVisit($xdt->id); ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="well">
                            <h4>Informasi : </h4>
                            <p>Klik <b>nama atau NIK</b> untuk pemantauan/ pemeriksaan pasien.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#dataTables').DataTable({
            responsive: true
        });
    });
</script>
