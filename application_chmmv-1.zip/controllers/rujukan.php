<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Rujukan extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (fUser('usrrole') == "") {
            redirect(base_url());
        }
    }

    public function index() {
        $this->template->load('template/general_temp', 'welcome_message');
    }

    function obatan($pilih = '', $idx = '') {
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Data Obatan';
                $dt['aksi'] = base_url() . 'index.php/rujukan/obatan/simpan';
                $this->template->load('template/general_temp', 'rujukan/form_obatan', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Data Obatan ';
                $dt['aksi'] = base_url() . 'index.php/rujukan/obatan/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tbl_obat', "id = '$idx'");
                $this->template->load('template/general_temp', 'rujukan/form_obatan', $dt);
                break;

            case "update":
                $datadb = array(
                    'obat_nama' => $this->db->escape_str($this->input->post('obat_nama'))
                );
                $this->db->where("id", $idx);
                $this->db->update('tbl_obat', $datadb);
                redirect(base_url() . 'index.php/rujukan/obatan');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tbl_obat');
                redirect(base_url() . 'index.php/rujukan/obatan');
                break;

            case "simpan":
                $datadb = array(
                    'obat_nama' => $this->db->escape_str($this->input->post('obat_nama'))
                );
                $this->db->insert('tbl_obat', $datadb);
                redirect(base_url() . 'index.php/rujukan/obatan');
                break;

            default :
                $dt['judul'] = 'Daftar Data Obatan - ' . APPNAME;
                $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_obat");
                $dt['tambah'] = base_url() . 'index.php/rujukan/obatan/tambah';
                $dt['edit'] = base_url() . 'index.php/rujukan/obatan/edit/';
                $dt['hapus'] = base_url() . 'index.php/rujukan/obatan/hapus/';
                $this->template->load('template/general_temp', 'rujukan/list_obatan', $dt);
        }
    }

    function penyakit($pilih = '', $idx = '') {
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Data Penyakit';
                $dt['aksi'] = base_url() . 'index.php/rujukan/penyakit/simpan';
                $this->template->load('template/general_temp', 'rujukan/form_penyakit', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Data Penyakit ';
                $dt['aksi'] = base_url() . 'index.php/rujukan/penyakit/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tbl_penyakit', "id = '$idx'");
                $this->template->load('template/general_temp', 'rujukan/form_penyakit', $dt);
                break;

            case "update":
                $datadb = array(
                    'penyakit_nama' => $this->db->escape_str($this->input->post('penyakit_nama')),
                    'sort_name' => $this->db->escape_str($this->input->post('sort_name'))
                );
                $this->db->where("id", $idx);
                $this->db->update('tbl_penyakit', $datadb);
                redirect(base_url() . 'index.php/rujukan/penyakit');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tbl_penyakit');
                redirect(base_url() . 'index.php/rujukan/penyakit');
                break;

            case "simpan":
                $datadb = array(
                    'penyakit_nama' => $this->db->escape_str($this->input->post('penyakit_nama')),
                    'sort_name' => $this->db->escape_str($this->input->post('sort_name'))
                );
                $this->db->insert('tbl_penyakit', $datadb);
                redirect(base_url() . 'index.php/rujukan/penyakit');
                break;

            default :
                $dt['judul'] = 'Daftar Data Penyakit - ' . APPNAME;
                $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_penyakit");
                $dt['tambah'] = base_url() . 'index.php/rujukan/penyakit/tambah';
                $dt['edit'] = base_url() . 'index.php/rujukan/penyakit/edit/';
                $dt['hapus'] = base_url() . 'index.php/rujukan/penyakit/hapus/';
                $this->template->load('template/general_temp', 'rujukan/list_penyakit', $dt);
        }
    }

    function unitorg($pilih = '', $idx = '') {
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Unit Organisasi';
                $dt['aksi'] = base_url() . 'index.php/rujukan/unitorg/simpan';
                $this->template->load('template/general_temp', 'rujukan/form_unitorg', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Unit Organisasi ';
                $dt['aksi'] = base_url() . 'index.php/rujukan/unitorg/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tbl_unitorg', "id = '$idx'");
                $this->template->load('template/general_temp', 'rujukan/form_unitorg', $dt);
                break;

            case "update":
                $datadb = array(
                    'unor_name' => $this->db->escape_str($this->input->post('unor_name'))
                );
                $this->db->where("id", $idx);
                $this->db->update('tbl_unitorg', $datadb);
                redirect(base_url() . 'index.php/rujukan/unitorg');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tbl_unitorg');
                redirect(base_url() . 'index.php/rujukan/unitorg');
                break;

            case "simpan":
                $datadb = array(
                    'unor_name' => $this->db->escape_str($this->input->post('unor_name'))
                );
                $this->db->insert('tbl_unitorg', $datadb);
                redirect(base_url() . 'index.php/rujukan/unitorg');
                break;

            default :
                $dt['judul'] = 'Daftar Unit Organisasi - ' . APPNAME;
                $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_unitorg");
                $dt['tambah'] = base_url() . 'index.php/rujukan/unitorg/tambah';
                $dt['edit'] = base_url() . 'index.php/rujukan/unitorg/edit/';
                $dt['hapus'] = base_url() . 'index.php/rujukan/unitorg/hapus/';
                $this->template->load('template/general_temp', 'rujukan/list_unitorg', $dt);
        }
    }

    function pengguna($pilih = '', $idx = '') {
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Pengguna ' . APPNAME;
                $dt['aksi'] = base_url() . 'index.php/rujukan/pengguna/simpan';
                $this->template->load('template/general_temp', 'rujukan/form_pengguna', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Pengguna ' . APPNAME;
                $dt['aksi'] = base_url() . 'index.php/rujukan/pengguna/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tbl_pengguna', "id = '$idx'");
                $this->template->load('template/general_temp', 'rujukan/form_pengguna', $dt);
                break;

            case "simpan":
                $datadb = array(
                    'usr_fullname' => $this->db->escape_str($this->input->post('usr_fullname')),
                    'usr_name' => seo_title($this->input->post('usr_name')),
                    'usr_passw' => md5($this->input->post('usr_passw')),
                    'usr_unit' => $this->input->post('usr_unit')
                );
                $this->db->insert('tbl_pengguna', $datadb);
                redirect(base_url() . 'index.php/rujukan/pengguna');
                break;

            case "update":
                if ($this->input->post('usr_passw') != '1234567890') {
                    $datadb = array(
                        'usr_fullname' => $this->db->escape_str($this->input->post('usr_fullname')),
                        'usr_name' => seo_title($this->input->post('usr_name')),
                        'usr_passw' => md5($this->input->post('usr_passw')),
                        'usr_unit' => $this->input->post('usr_unit')
                    );
                } else {
                    $datadb = array(
                        'usr_fullname' => $this->db->escape_str($this->input->post('usr_fullname')),
                        'usr_name' => seo_title($this->input->post('usr_name')),
                        'usr_unit' => $this->input->post('usr_unit')
                    );
                }
                $this->db->where("id", $idx);
                $this->db->update('tbl_pengguna', $datadb);
                redirect(base_url() . 'index.php/rujukan/pengguna');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tbl_pengguna');
                redirect(base_url() . 'index.php/rujukan/pengguna');
                break;

            default :
                $dt['judul'] = 'Daftar Pengguna ' . APPNAME;
                $dt['dtlist'] = $this->db->get_where('tbl_pengguna', "status = '1'");
                $dt['tambah'] = base_url() . 'index.php/rujukan/pengguna/tambah';
                $dt['edit'] = base_url() . 'index.php/rujukan/pengguna/edit/';
                $dt['hapus'] = base_url() . 'index.php/rujukan/pengguna/hapus/';
                $this->template->load('template/general_temp', 'rujukan/list_pengguna', $dt);
        }
    }

    function dokterperawat($pilih = '', $idx = '') {
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Data dokter/ perawat';
                $dt['aksi'] = base_url() . 'index.php/rujukan/dokterperawat/simpan';
                $this->template->load('template/general_temp', 'rujukan/form_dokterperawat', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Data Dokter/ Perawat ';
                $dt['aksi'] = base_url() . 'index.php/rujukan/dokterperawat/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tbl_dokterperawat', "id = '$idx'");
                $this->template->load('template/general_temp', 'rujukan/form_dokterperawat', $dt);
                break;

            case "update":
                $datadb = array(
                    'nama_dokpera' => $this->db->escape_str($this->input->post('nama_dokpera')),
                    'id_pkm' => fUser('usrunit')
                );
                $this->db->where("id", $idx);
                $this->db->update('tbl_dokterperawat', $datadb);
                redirect(base_url() . 'index.php/rujukan/dokterperawat');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tbl_dokterperawat');
                redirect(base_url() . 'index.php/rujukan/dokterperawat');
                break;

            case "simpan":
                $datadb = array(
                    'nama_dokpera' => $this->db->escape_str($this->input->post('nama_dokpera')),
                    'id_pkm' => fUser('usrunit')
                );
                $this->db->insert('tbl_dokterperawat', $datadb);
                redirect(base_url() . 'index.php/rujukan/dokterperawat');
                break;

            default :
                $dt['judul'] = 'Daftar Data dokter/ perawat - ' . APPNAME;
                if (fUser('usrrole') == 'admin') {
                    $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_dokterperawat");
                } else {
                    $unit = fUser('usrunit');
                    $dt['dtlist'] = $this->db->query("SELECT * FROM tbl_dokterperawat WHERE id_pkm = '$unit'");
                }
                $dt['tambah'] = base_url() . 'index.php/rujukan/dokterperawat/tambah';
                $dt['edit'] = base_url() . 'index.php/rujukan/dokterperawat/edit/';
                $dt['hapus'] = base_url() . 'index.php/rujukan/dokterperawat/hapus/';
                $this->template->load('template/general_temp', 'rujukan/list_dokterperawat', $dt);
        }
    }

    function loginpages() {
        if ($this->input->post()) {
            echo "submit oke";
        }

        $dt['aksi_url'] = base_url() . 'index.php/welcome/loginpages';
        $this->template->load('template/general_temp', 'login_pages', $dt);
    }

}
