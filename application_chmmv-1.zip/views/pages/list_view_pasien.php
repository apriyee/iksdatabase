<h1><?= APPNAME; ?></h1>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-group fa-fw"></i> <?= $judul; ?></b>
                <div class="pull-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" onclick="printDiv('printArea')">Cetak</a></li>
                            <li class="divider"></li>
                            <li><a href="#">Separated link</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="col-md-12">
                    <div class="row">
                        <?php
                        $thn = $this->input->post('tahun') ? $this->input->post('tahun') : date('Y', time());
                        ?>
                        <form action="" method="post">
                            <div class="form-group input-group">
                                <span class="input-group-addon">Tahun</span>
                                <input type="text" name="tahun" id="tahun" 
                                       value="<?= $thn; ?>"
                                       class="form-control" 
                                       style="max-width: 4; width: 80px;">
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row" id="printArea">
                    <div class="col-lg-12">
                        <h3><?= $judul; ?> Tahun <?= $thn; ?></h3>
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered"  style="font-size: 0.8em;">
                                <thead>
                                    <tr>
                                        <th rowspan="2">Nama</th>
                                        <th rowspan="2">NIK</th>
                                        <th rowspan="2">Tempat Tgl. Lahir<br>Umur</th>
                                        <th rowspan="2">Alamat</th>
                                        <th rowspan="2">Awal Kontak</th>
                                        <th rowspan="2">No. BPJS</th>
                                        <th colspan="12">PEMANTAUAN</th>
                                    </tr>
                                    <tr>
                                        <?php foreach (fshortbln() as $ix => $sbln) { ?>
                                            <th><?= $sbln; ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($dtlist->num_rows() > 0) {
                                        foreach ($dtlist->result() as $xdt) {
                                            $hari = date('d', time());
                                            $ketemu = fKetemu($xdt->id, $idpeny);
                                            ?>
                                            <tr class="odd gradeX">
                                                <td><?= $xdt->pasien_nama; ?></td>
                                                <td><?= $xdt->nik; ?></td>
                                                <td><?= $xdt->tmp_lahir; ?>/ <?= date('d-m-Y', strtotime($xdt->tgl_lahir)); ?>
                                                    <br><?= hitung_umur($xdt->tgl_lahir); ?></td>
                                                <td><?= $xdt->alamat; ?></td>
                                                <td><?= tgl($ketemu); ?></td>
                                                <td><?= $xdt->nomor_bpjs; ?></td>
                                                <?php
                                                $tg1 = date('Y-m-d', strtotime($ketemu));
                                                foreach (fshortbln() as $ix => $sbln) {
                                                    $hitstd = $thn . '-' . $ix . '-' . $hari;
                                                    $std = fHitStandart($tg1, $hitstd);
                                                    ?>
                                                    <td><?= $std; ?></td>
                                                <?php } ?>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
//    $(document).ready(function () {
//        $('#dataTables').DataTable({
//            responsive: true
//        });
//    });
</script>
