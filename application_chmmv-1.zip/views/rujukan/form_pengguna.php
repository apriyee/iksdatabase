<?php
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$usr_fullname = isset($dtEdit) ? $rows->usr_fullname : '';
$usr_name = isset($dtEdit) ? $rows->usr_name : '';
$usr_passw = isset($dtEdit) ? '1234567890' : '';
$usr_passw_read = isset($dtEdit) ? ', <br><span style="color:red">ABAIKAN JIKA TIDAK INGGIN MENGGANTI PASSWORD!.</span>' : '';
$usr_name_read = isset($dtEdit) ? 'readonly=""' : '';
$usr_unit = isset($dtEdit) ? $rows->usr_unit : '';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input class="form-control" name="usr_fullname" id="usr_fullname"
                                       value="<?= $usr_fullname; ?>">
                                <p class="help-block">Isikan Nama lengkap pengguna.</p>
                            </div>
                            <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" name="usr_name" id="usr_name"
                                       value="<?= $usr_name; ?>" <?= $usr_name_read; ?>>
                                <p class="help-block">Akan dipergunakan untuk login.</p>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="usr_passw" id="usr_passw"
                                       value="<?= $usr_passw; ?>">
                                <p class="help-block">Gunakan password yang mudah diingat sendiri<?= $usr_passw_read; ?></p>
                            </div>
                            <div class="form-group">
                                <label>Unit Organisasi</label>
                                <?php
                                $stylsst = "class='form-control input-sm select2-single' id='usr_unit'";
                                $options = array();
                                $options[''] = '--Pilih Unit Organisasi--';
                                foreach (fTbUnor()->result() as $org) {
                                    $options[$org->id] = $org->unor_name;
                                }
                                echo form_dropdown('usr_unit', $options, $usr_unit, $stylsst);
                                ?>
                                <p class="help-block">Gunakan/ Pilih SKPD atau apalah-apalah</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>
