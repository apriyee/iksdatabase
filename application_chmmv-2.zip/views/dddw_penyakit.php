<div class="form-group">
    <label>Indikasi Penyakit</label>
    <?php
    $styls = "class='form-control input-sm peny-results' "
            . "id='id_penyakit' $readId";
    $optio = array();
    $optio[''] = '--Pilihan--';
    foreach (fTbPenyakit()->result() as $py) {
        $optio[$py->id] = $py->penyakit_nama;
    }
    echo form_dropdown('id_penyakit', $optio, $id_penyakit, $styls);
    ?>
</div>


