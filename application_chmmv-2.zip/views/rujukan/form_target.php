<?php
$idunor = $idtarget;
$thn = $this->input->get('thn');
$indikasi = $this->input->get('indikasi');
$rows = fTarget($idunor, $thn, $indikasi);
if ($rows->result()) {
    $res = $rows->row();
    $target = $res->target;
    $aksi = base_url()."rujukan/unitorg/update_target";
} else {
    $target = 0;
    $aksi = base_url()."rujukan/unitorg/save_target";
}

//from tbl_pkmtarget
//$rows = isset($dtEdit) ? $dtEdit->row() : array();
//$usr_fullname = isset($dtEdit) ? $rows->unor_name : '';
?>
<p>&nbsp;</p>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><?= $judul; ?> <?= fTbUnor($idunor); ?></b></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama Unit Organisasi</label>
                                <input class="form-control" type="hidden" name="idunit" id="idunit" 
                                       value="<?= $idunor; ?>">
                                <input class="form-control" name="unor_name" id="unor_name"
                                       readonly="" value="<?= fTbUnor($idunor); ?>">
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">Tahun</span>
                                <input class="form-control" name="tahun" id="tahun"
                                       readonly="" value="<?= $thn; ?>">
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">Penderita <?= fTbPenyakit($indikasi); ?></span>
                                <input class="form-control" name="idpeny" id="idpeny"
                                       readonly="" value="<?= $indikasi; ?>">
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">Target </span>
                                <input class="form-control" name="target" id="target" value="<?= $target; ?>">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>