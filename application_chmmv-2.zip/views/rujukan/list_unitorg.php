<?php
$thn = $this->input->post('tahun') ? $this->input->post('tahun') : date('Y', time());
?>
<!-- /.row -->
<div class="row">
    <div class="col-lg-3">
        <form role="form" method="POST">
            <div class="form-group input-group">
                <span class="input-group-addon">Tahun</span>
                <input type="text" class="form-control" name="tahun" value="<?= $thn; ?>">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button" onclick="this.form.submit()">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-home fa-fw"></i> <?= $judul; ?> Tahun <?= $thn; ?></b>
                <div class="pull-right">
                    <a href="<?= $tambah; ?>">
                        <button type="button" class="btn btn-default btn-xs">
                            <i class="fa fa-plus fa-fw"></i> Tambah Unit Organisasi
                        </button>
                    </a>
                </div>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="dataTable_wrapper">
                            <table class="table table-striped table-bordered table-hover" id="dataTables">
                                <thead>
                                    <tr>
                                        <th rowspan="2">No.</th>
                                        <th rowspan="2">OPSI</th>
                                        <th rowspan="2">NAMA UNIT ORGANISASI</th>
                                        <th colspan="<?= fTbPenyakit()->num_rows(); ?>"
                                            style="text-align: center;">TARGET</th>
                                    </tr>
                                    <tr>
                                        <?php
                                        foreach (fTbPenyakit()->result() as $h) {
                                            ?>
                                            <th><?= $h->sort_name; ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($dtlist->num_rows() >= 1) {
                                        $ulang = 0;
                                        foreach ($dtlist->result() as $xdt) {
                                            $ulang++;
                                            ?>
                                            <tr class="odd gradeX">
                                                <td><?= $ulang; ?></td>
                                                <td class="center-block">
                                                    <a href="<?= $hapus; ?><?= $xdt->id; ?>" onclick="return confirm('Yakin data akan diHapus?')">
                                                        <button type="button" class="btn btn-danger btn-xs">
                                                            <i class="fa fa-times"></i> Hapus</button>
                                                    </a>
                                                    <a href="<?= $edit; ?><?= $xdt->id; ?>">
                                                        <button type="button" class="btn btn-success btn-xs">
                                                            <i class="fa fa-edit"></i>  Edit</button>
                                                    </a>
                                                    <a href="<?= base_url(); ?>index.php/viewlist/rekperorg/<?= $xdt->id; ?>">
                                                        <button type="button" class="btn btn-default btn-xs">
                                                            <i class="fa fa-search"></i> Preview
                                                        </button>
                                                        
                                                    </a>
                                                </td>
                                                <td><?= $xdt->unor_name; ?></td>
                                                <?php
                                                $ntarget = 0;
                                                foreach (fTbPenyakit()->result() as $r) {
                                                    $xrows = fTarget($xdt->id, $thn, $r->id);
                                                    if ($xrows->result()) {
                                                        $ntarget = $xrows->row()->target;
                                                    }
                                                    ?>
                                                <td style="text-align: center">
                                                    <a href="<?= $target.$xdt->id; ?>?thn=<?= $thn; ?>&indikasi=<?=$r->id; ?>">
                                                    <button type="button" class="btn btn-info btn-xs">
                                                            <i class="fa fa-edit"></i>  <?= $ntarget; ?></button></a>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <tr class="odd gradeX">
                                            <td>-- Data tidak di ketemukan -- </td>
                                            <td>--</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<script>
    $(document).ready(function () {
        $('#dataTables').DataTable({
            responsive: true
        });
    });
</script>