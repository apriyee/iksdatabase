<?php
//$pkm = fUser('usrrole') != '' ? fUser('usrunit') : "";
$pkm = fUser('usrrole') != 'users' ? "" : fUser('usrunit');
$pkm_name = fUser('usrrole') != 'users' ? "" : fTbUnor($pkm);
$tahun = date('Y', time());
?>
<h1>Pasien <?= $pkm_name; ?> per Th. <?= $tahun; ?></h1>
<link href="<?= base_url(); ?>assets/morrisjs/morris.css" rel="stylesheet">
<script src="<?= base_url(); ?>assets/raphael/raphael-min.js"></script>
<script src="<?= base_url(); ?>assets/morrisjs/morris.min.js"></script>
<!--<script src="< ?= base_url(); ?>assets/morrisjs/morris-data.js"></script>-->

<div class="row">
    <?php
    $panel = array('panel-primary', 'panel-green', 'panel-info', 'panel-yellow', 'panel-danger', 'panel-default', 'panel-red', 'panel-success');
    $random_keys = array_rand($panel, count($panel));
    ?>
</div>
<div class="row">
    <?php
    $xnum = 0;
    foreach (fTbPenyakit()->result() as $dp) {
        ?>
        <div class="col-lg-3 col-md-6">
            <div class="panel <?= $panel[$random_keys[$xnum]]; ?>">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-comments fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge"><?= f_hit_pasien($pkm, $dp->id, $tahun, ""); ?></div>
                            <div>Pasien <br><?= $dp->penyakit_nama; ?></div>
                        </div>
                    </div>
                </div>
                <a href="<?= base_url(); ?>index.php/viewlist/pasien/<?= $dp->id; ?>">
                    <div class="panel-footer">
                        <span class="pull-left">View Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <?php
        $xnum++;
    }
    ?>

    <div class="col-lg-3 col-md-6">
        <div class="panel <?= $panel[$random_keys[count($panel) - 1]]; ?>">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-home fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= f_jml_unor(); ?></div>
                        <div>Unit Organisasi</div>
                    </div>
                </div>
            </div>
            <a href="<?= base_url(); ?>viewlist/unitorg">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-bar-chart-o fa-fw"></i> Standart Pasien s.d. <?= date('F, Y', time()); ?>
                <div class="pull-right"></div>
            </div>
            <div class="panel-body">
                <div id="morris-bar-chart"></div>
                <!--<div id="morris-area-chart"></div>-->
            </div>
        </div>
    </div>
</div>
<?php
//echo fHitStandart('2020-03-15 0:0:0','2021-11-02');
//hitung jumlah standart dari pertama kali kontak

$key = array();
$label = array();
$dtgr = array();
$barval = array();


$start = new DateTime;
$timezone = "Singapore";
date_default_timezone_set($timezone);
$start->setDate($start->format('Y'), $start->format('n'), 1);
$start->setTime(0, 0, 0); // Normalize time to midnight
$start->sub(new DateInterval('P12M'));
$interval = new DateInterval('P1M');
$recurrences = 12;

foreach (new DatePeriod($start, $interval, $recurrences, true) as $date) {
    $bln = $date->format('m');
    $thn = $date->format('Y');
    foreach (fTbPenyakit()->result() as $idp) {
        $dtgr['period'] = $date->format('M, Y');
        $dtgr[$idp->sort_name] = fJpasienPenyBlnThn($idp->id, $bln, $thn);
    }
    $barval[] = $dtgr;
}

foreach (fTbPenyakit()->result() as $idp) {
    $key[] = $idp->sort_name;
    $label[] = $idp->penyakit_nama;
}
?>

<script>
    $(function () {
        Morris.Bar({
            element: 'morris-bar-chart',
            data: <?= json_encode($barval); ?>,
            xkey: 'period',
            ykeys: <?= json_encode($key); ?>, //['a', 'b'],
            labels: <?= json_encode($label); ?>,
            hideHover: 'auto',
            resize: true
        });
    });
</script>