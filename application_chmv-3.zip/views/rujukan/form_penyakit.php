<?php
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$usr_fullname = isset($dtEdit) ? $rows->penyakit_nama : '';
$sort_name = isset($dtEdit) ? $rows->sort_name : '';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama Penyakit</label>
                                <input class="form-control" name="penyakit_nama" id="penyakit_nama"
                                       value="<?= $usr_fullname; ?>">
                                <p class="help-block">Isikan Nama penyakit.</p>
                            </div>
                            <div class="form-group">
                                <label>Nama Penyakit Singkat</label>
                                <input class="form-control" name="sort_name" id="sort_name"
                                       value="<?= $sort_name; ?>">
                                <p class="help-block">Isikan Nama penyakit singkat.</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>