<?php
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$nama_dokpera = isset($dtEdit) ? $rows->nama_dokpera : '';
$readId = ""; //fUser('usrrole') != "admin" ? "style='pointer-events: none; touch-action: none;'" : '';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama dokter/ perawat</label>
                                <input class="form-control" name="nama_dokpera" id="obat_nama" 
                                       value="<?= $nama_dokpera; ?>">
                                <p class="help-block">Nama lengkap dokter/ perawat.</p>
                            </div>
<!--                            <div class="form-group">
                                <label>Unit Organisasi</label>
                                <?php
                                $stylsst = "class='form-control input-sm unit-results' "
                                        . "id='id_pkm' $readId";
                                $options = array();
                                $options[''] = '--Pilih Unit Organisasi--';
                                foreach (fTbUnor()->result() as $org) {
                                    $options[$org->id] = $org->unor_name;
                                }
                                echo form_dropdown('id_pkm', $options, $id_pkm, $stylsst);
                                ?>
                                <p class="help-block">Gunakan/ Pilih SKPD atau apalah-apalah</p>
                            </div>-->
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('.unit-results').select2();
    });
</script>