<?php
$pkm = fUser('usrunit');
$rows = isset($dtEdit) ? $dtEdit->row() : array();
//$usrent = isset($dtEdit) ? $rows->usrent : fUser('usrname');
//$readId = fUser('usrrole') != "admin" ? "Disabled" : '';

$id = isset($dtEdit) ? $rows->id_pasien : $id;
$tgl_periksa = isset($dtEdit) ? date('Y-m-d', strtotime($rows->tgl_periksa)) : '';
$id_pasien = isset($dtEdit) ? $rows->id_pasien : $id;
$pemeriksa = isset($dtEdit) ? $rows->pemeriksa : '';
$pasien_nama = isset($dtEdit) ? $rows->pasien_nama : fNamaPasien($id);

$id_penyakit = isset($dtEdit) ? explode(",", $rows->id_penyakit) : '';
$resep = isset($dtEdit) ? explode(",", $rows->resep) : '';
$tindakan = isset($dtEdit) ? $rows->tindakan : '';

$ROL = "2";
//fUser('usrnama'); 
?>
<h1><?= $judul . ' ' . fNamaPasien($id); ?></h1>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"></div>
            <div class="panel-body">
                <div class="row">
                    <form role="form" method="POST" action="<?= $aksi; ?>">
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="tgl_lahir">Tanggal Pemeriksaan</label>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon">Tgl.</span>
                                            <input class="form-control datepicker" name="tgl_periksa" 
                                                   id="tgl_periksa" value="<?= $tgl_periksa; ?>" 
                                                   autocomplete="off">
                                            <span class="input-group-addon" style="color: red"><i class="fa fa-calendar"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label>ID Pasien/ Nama </label>
                            <div class="form-group">
                                <input class="form-control" name="id_pasien" type="hidden"
                                       id="id_pasien" value="<?= $id_pasien; ?>">
                                <input class="form-control" name="pasien_nama" id="pasien_nama" 
                                       autocomplete="off" readonly=""
                                       value="<?= $pasien_nama; ?>">
                            </div>
                            <div class="form-group">
                                <label>Dokter/ Perawat</label>
                                <?php
                                $stylss = "class='form-control input-sm peny-results' "
                                        . "id='pemeriksa'";
                                $opt = array();
                                $opt[''] = '-- pilihan --';
                                foreach (fTbDokter()->result() as $d) {
                                    if (fUser('usrrole') != "admin") {
                                        if ($d->id_pkm == fUser('usrunit')) {
                                            $opt[$d->id] = $d->nama_dokpera;
                                        }
                                    } else {
                                        $opt[$d->id] = $d->nama_dokpera;
                                    }
                                }
                                echo form_dropdown('pemeriksa', $opt, $pemeriksa, $stylss);
                                ?>
                            </div>
                            <div class="form-group">
                                <label>Indikasi Penyakit</label>
                                <?php
                                $styls = "class='form-control input-sm peny-results' "
                                        . "id='id_penyakit' multiple='multiple'";
                                $optio = array();
                                foreach (fTbPenyakit()->result() as $py) {
                                    $optio[$py->id] = $py->penyakit_nama;
                                }
                                echo form_dropdown('id_penyakit[]', $optio, $id_penyakit, $styls);
                                ?>
                            </div>
                            <div class="form-group">
                                <label>Tindakan dokter/ perawat</label>
                                <textarea class="form-control" name="tindakan" id="tindakan" 
                                          rows="3"><?= $tindakan; ?></textarea>
                                <p class="help-block">Tindakan penanganan dokter atau perawat.</p>
                            </div>
                            <div class="form-group">
                                <label>Pemberian Obat</label>
                                <?php
                                $styl = "class='form-control input-sm peny-results' "
                                        . "id='resep'  multiple='multiple'";
                                $opti = array();
                                foreach (fTbObat()->result() as $ob) {
                                    $opti[$ob->id] = $ob->obat_nama;
                                }
                                echo form_dropdown('resep[]', $opti, $resep, $styl);
                                ?>
                                <p class="help-block">dapat dipilih lebih dari satu.</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </div>
                    </form>
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">Catatan Pemeriksaan</div>
                            <!-- .panel-heading -->
                            <div class="panel-body">
                                <div class="panel-group" id="accordion">
                                    <?php
                                    if (isset($dtperiksa)) {
                                        $item = 0;
                                        foreach ($dtperiksa->result() as $log) {
                                            $collap = $item == 0 ? "in" : "";
                                            //$id_penyakit = isset($dtEdit) ? explode(",", $rows->id_penyakit) : '';
                                            $list_peny = explode(",", $log->id_penyakit); //$log->id_penyakit;
                                            $list_resep = explode(",", $log->resep);
                                            ?>
                                            <div class = "panel panel-default">
                                                <div class = "panel-heading">
                                                    <h4 class = "panel-title">
                                                        <a data-toggle = "collapse" data-parent = "#accordion" href = "#<?= $log->id; ?>"><?= tgl($log->tgl_periksa); ?></a>
                                                        <div class="pull-right">
                                                            <a href="<?= $edit . $log->id; ?>">
                                                                <button type="button" class="btn btn-default btn-xs">
                                                                    <i class="fa fa-pencil fa-fw"></i> Edit
                                                                </button>
                                                            </a>
                                                        </div>
                                                    </h4>
                                                </div>
                                                <div id = "<?= $log->id; ?>" class = "panel-collapse collapse <?= $collap; ?>">
                                                    <div class = "panel-body">
                                                        <h5><b>Dokter/ Perawat Pemeriksa</b></h5>
                                                        <p><?= $log->tindakan; ?></p>
                                                        <h5><b>Indikasi Penyakit</b></h5>
                                                        <p><?php
                                                            foreach ($list_peny as $idx1) {
                                                                if (!next($list_peny)) {
                                                                    echo fTbPenyakit($idx1);
                                                                } else {
                                                                    echo fTbPenyakit($idx1) . ", ";
                                                                }
                                                            }
                                                            ?></p>
                                                        <h5><b>Tindakan Dokter</b></h5>
                                                        <p><?= $log->tindakan; ?></p>
                                                        <h5><b>Pemberian Obat</b></h5>
                                                        <p><?php
                                                            foreach ($list_resep as $idx2) {
                                                                if (!next($list_resep)) {
                                                                    echo fTbObat($idx2);
                                                                } else {
                                                                    echo fTbObat($idx2) . ", ";
                                                                }
                                                            }
                                                            ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            $item++;
                                        }
                                    }
                                    ?>

                                </div>
                            </div>
                            <!--.panel-body -->
                        </div>
                        <!--/.panel -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script type = "text/javascript">
    $(document).ready(function () {
        $('.unit-results').select2();
        $('.peny-results').select2();

        $(".datepicker").datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true,
        });
    });

    $('form').submit(function () {
        var tgl = $.trim($('#tgl_periksa').val());
        var idenpeny = $.trim($('#id_penyakit').val());
        if (tgl === '') {
            alert('Tanggal pemeriksaan wajib diisi.');
            return false;
        }
        if (idenpeny === '') {
            alert('Identifikasi Penyakit wajib diisi.');
            return false;
        }
    });
</script>