<?php
$pkm = fUser('usrunit');
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$id_unor = isset($dtEdit) ? $rows->id_unor : $pkm;
$pasien_nama = isset($dtEdit) ? $rows->pasien_nama : '';
$tmp_lahir = isset($dtEdit) ? $rows->tmp_lahir : '';
$tgl_lahir = isset($dtEdit) ? date('Y-m-d', strtotime($rows->tgl_lahir)) : '';
$nomor_bpjs = isset($dtEdit) ? $rows->nomor_bpjs : '';
$nik = isset($dtEdit) ? $rows->nik : '';
$alamat = isset($dtEdit) ? $rows->alamat : '';
$penjamin = isset($dtEdit) ? $rows->penjamin : '';
$sts_penjamin = isset($dtEdit) ? $rows->sts_penjamin : '';
$usrent = isset($dtEdit) ? $rows->usrent : fUser('usrname');
//$tgl_ditemukan = isset($dtEdit) ? date('Y-m-d', strtotime($rows->tgl_ditemukan)) : '';

$readId = ""; //fUser('usrrole') != "admin" ? "Disabled" : '';
//fUser('usrnama'); 
?>
<h1><?= fTbUnor($pkm); ?></h1>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <form role="form" method="POST" action="<?= $aksi; ?>">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Nama Pasien</label>
                                <input class="form-control" name="pasien_nama" id="pasien_nama" 
                                       autocomplete="off"
                                       value="<?= $pasien_nama; ?>">
                                <p class="help-block">Isikan Nama Lengkap Pasien.</p>
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input class="form-control col-lg-4" name="tmp_lahir" id="tmp_lahir"
                                       autocomplete="off"
                                       value="<?= $tmp_lahir; ?>">
                                <p class="help-block">Isikan Nama Lengkap Pasien.</p>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">Tgl.</span>
                                <input class="form-control datepicker" name="tgl_lahir" 
                                       id="tgl_lahir" value="<?= $tgl_lahir; ?>" 
                                       autocomplete="off">
                                <span class="input-group-addon">||</span>
                            </div>
                            <div class="form-group">
                                <label>Penanggung Jawab</label>
                                <input class="form-control col-lg-4" name="penjamin" id="penjamin"
                                       autocomplete="off"
                                       value="<?= $penjamin; ?>">
                                <p class="help-block">*) <span style="color: red">Khusus penderita ODGJ.</span></p>
                            </div>
                            <div class="form-group">
                                <label>Phone Penanggung Jawab</label>
                                <input class="form-control col-lg-4" name="sts_penjamin" id="sts_penjamin"
                                       autocomplete="off"
                                       value="<?= $sts_penjamin; ?>">
                                <p class="help-block">No. Telp./HP</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>No. BPJS</label>
                                <input class="form-control" name="nomor_bpjs" id="nomor_bpjs"
                                       autocomplete="off"
                                       value="<?= $nomor_bpjs; ?>">
                                <p class="help-block">Nomor BPJS</p>
                            </div>
                            <div class="form-group">
                                <label>NIK</label>
                                <input class="form-control" name="nik" id="nik"
                                       autocomplete="off"
                                       value="<?= $nik; ?>">
                                <p class="help-block">Nomor Identitas Kependudukan/ Nasional</p>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" name="alamat" id="alamat" 
                                          rows="3"><?= $alamat; ?></textarea>
                                <p class="help-block">Alamat lengkap sesuai KTP/Kartu Identitas Lainnya</p>
                            </div>
                            <div class="form-group">
                                <label>Unit Organisasi</label>
                                <?php
                                $styl = "class='form-control input-sm unit-results' "
                                        . "id='id_unor' $readId";
                                $opti = array();
                                $opti[''] = '--Pilih Unit Organisasi--';
                                foreach (fTbUnor()->result() as $org) {
                                    $opti[$org->id] = $org->unor_name;
                                }
                                echo form_dropdown('id_unor', $opti, $id_unor, $styl);
                                ?>
                            </div>
                            <div class="form-group">
                                <label>Petugas </label>
                                <input class="form-control col-lg-4" name="usrent" id="usrent"
                                       readonly="" value="<?= $usrent; ?>">
                                <p>Mengetahui petugas </p>
                            </div>
                        </div>
                    </div>
                </form>
                <!-- /.col-lg-6 (nested) -->
                
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('.unit-results').select2();
        $('.peny-results').select2();

        $(".datepicker").datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true,
        });
    });
</script>