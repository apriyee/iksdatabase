<?php

class Model_view_list extends CI_model {

    function view_pasien($pkm = '', $peny = "") {
        $this->db->select('tb_pasien.*, COUNT(tb_pemeriksaan.id) AS jml');
        $this->db->from('tb_pemeriksaan');
        $this->db->join('tb_pasien', 'tb_pemeriksaan.id_pasien = tb_pasien.id', 'left');
        if (fUser('usrrole') == 'users') {
            if ($pkm != '') {
                $this->db->where("tb_pasien.id_unor", $pkm);
            }
        }
        if ($peny != '') {
            $this->db->like('tb_pemeriksaan.id_penyakit', $peny, 'both');
        }
        $this->db->group_by('tb_pemeriksaan.id_pasien');
        return $this->db->get();
    }

    function _sum_rek_perbulan($pkm = '', $peny = '', $thn = '', $bln = '') {
        $this->db->select('SUM(tb_pemeriksaan.id) as org', false);
        $this->db->from('tb_pemeriksaan');
        $this->db->join('tb_pasien', 'tb_pemeriksaan.id_pasien = tb_pasien.id', 'left');
        if ($pkm != '') {
            $this->db->where("tb_pasien.id_unor", $pkm);
        }
        if ($peny != '') {
            $this->db->like('tb_pemeriksaan.id_penyakit', $peny, 'both');
        }
        $this->db->where("YEAR(tb_pemeriksaan.tgl_periksa)", $thn);
        $this->db->where("MONTH(tb_pemeriksaan.tgl_periksa)", $bln);
        $dbres = $this->db->get()->row();
        $count = $dbres->org >= 1 ? $dbres->org : 0;
        return $count;
    }

}
