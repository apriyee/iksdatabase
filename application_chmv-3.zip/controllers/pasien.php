<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pasien extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if( fUser('usrrole') == "") {
            redirect(base_url());
        }
    }

    public function index() {
        $this->daftar();
    }

    function daftar($pilih = '', $idx = '') {
        $ident = $this->input->get('ident');
        switch ($pilih) {
            case "tambah":
                $dt['judul'] = 'Tambah Data Pasien';
                $dt['aksi'] = base_url() . 'index.php/pasien/daftar/simpan';
                $this->template->load('template/general_temp', 'pasien/form_datapasien', $dt);
                break;

            case "edit":
                $dt['judul'] = 'Edit Data Pasien ';
                $dt['aksi'] = base_url() . 'index.php/pasien/daftar/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tb_pasien', "id = '$idx'");
                $this->template->load('template/general_temp', 'pasien/form_datapasien', $dt);
                break;

            case "update":
                $datadb = array(
                    'pasien_nama' => strtoupper($this->db->escape_str($this->input->post('pasien_nama'))),
                    'tmp_lahir' => strtoupper($this->db->escape_str($this->input->post('tmp_lahir'))),
                    'tgl_lahir' => $this->db->escape_str($this->input->post('tgl_lahir')),
                    'nomor_bpjs' => $this->db->escape_str($this->input->post('nomor_bpjs')),
                    'nik' => $this->db->escape_str($this->input->post('nik')),
                    'alamat' => strtoupper($this->db->escape_str($this->input->post('alamat'))),
                    'id_unor' => $this->input->post('id_unor'),
                    'usrent' => fUser('usrname')
                );
                $this->db->where("id", $idx);
                $this->db->update('tb_pasien', $datadb);
                redirect(base_url() . 'index.php/pasien/daftar');
                break;

            case "hapus":
                $this->db->where("id", $idx);
                $this->db->delete('tb_pasien');
                redirect(base_url() . 'index.php/pasien/daftar');
                break;

            case "simpan":
                $datadb = array(
                    'pasien_nama' => strtoupper($this->db->escape_str($this->input->post('pasien_nama'))),
                    'tmp_lahir' => strtoupper($this->db->escape_str($this->input->post('tmp_lahir'))),
                    'tgl_lahir' => $this->db->escape_str($this->input->post('tgl_lahir')),
                    'nomor_bpjs' => $this->db->escape_str($this->input->post('nomor_bpjs')),
                    'nik' => $this->db->escape_str($this->input->post('nik')),
                    'alamat' => strtoupper($this->db->escape_str($this->input->post('alamat'))),
                    'id_unor' => $this->input->post('id_unor'),
                    'usrent' => fUser('usrname')
                );
                $this->db->insert('tb_pasien', $datadb);
                redirect(base_url() . 'index.php/pasien/daftar');
                break;

            default :
                if (fUser('usrrole') == 'admin') {
                    $dt['judul'] = 'Data Pasien';
                    $dt['dtlist'] = $this->db->query("SELECT * FROM tb_pasien");
                } else {
                    $dt['judul'] = 'Data Pasien - ' . fTbUnor(fUser('usrunit'));
                    $unit = fUser('usrunit');
                    $filter = "id_unor = '$unit'";
                    $dt['dtlist'] = $this->db->query("SELECT * FROM tb_pasien WHERE $filter");
                }
                $dt['tambah'] = base_url() . 'index.php/pasien/daftar/tambah';
                $dt['edit'] = base_url() . 'index.php/pasien/daftar/edit/';
                $dt['hapus'] = base_url() . 'index.php/pasien/daftar/hapus/';
                $dt['periksa'] = base_url() . 'index.php/pasien/daftar/pemeriksaan/';
                $this->template->load('template/general_temp', 'pasien/list_pasien', $dt);
        }
    }

    function periksa($pilih = '', $idx = '') {
        switch ($pilih) {
            case "edit":
                $dt['judul'] = 'Edit pemeriksaan Pasien ';
                $dt['aksi'] = base_url() . 'index.php/pasien/periksa/update/' . $idx;
                $dt['dtEdit'] = $this->db->get_where('tb_pemeriksaan', "id = '$idx'");
                $this->template->load('template/general_temp', 'pemeriksaan/form_pemeriksaan', $dt);
                break;

            case "update":
                if (!empty($this->input->post('id_penyakit'))) {
                    $penyakit = implode(",", $this->input->post('id_penyakit'));
                }
                if (!empty($this->input->post('resep'))) {
                    $resep = implode(",", $this->input->post('resep'));
                }
                $datadb = array(
                    'tgl_periksa' => date('Y-m-d', strtotime($this->input->post('tgl_periksa'))),
                    'id_pasien' => $this->input->post('id_pasien'),
                    'pasien_nama' => strtoupper($this->db->escape_str($this->input->post('pasien_nama'))),
                    'id_penyakit' => $penyakit,
                    'pemeriksa' => $this->db->escape_str($this->input->post('pemeriksa')),
                    'tindakan' => $this->db->escape_str($this->input->post('tindakan')),
                    'resep' => $resep,
                    'usredt' => fUser('usrname'),
                    'tgledt' => date('Y-m-d H:m:d', time())
                );
                $this->db->where("id", $idx);
                $this->db->update('tb_pemeriksaan', $datadb);

                redirect(base_url() . 'index.php/pasien');
                break;

            case "simpan":
                if (!empty($this->input->post('id_penyakit'))) {
                    $penyakit = implode(",", $this->input->post('id_penyakit'));
                }
                if (!empty($this->input->post('resep'))) {
                    $resep = implode(",", $this->input->post('resep'));
                }
                $datadb = array(
                    'tgl_periksa' => date('Y-m-d', strtotime($this->input->post('tgl_periksa'))),
                    'id_pasien' => $this->input->post('id_pasien'),
                    'pasien_nama' => strtoupper($this->db->escape_str($this->input->post('pasien_nama'))),
                    'id_penyakit' => $penyakit,
                    'pemeriksa' => $this->db->escape_str($this->input->post('pemeriksa')),
                    'tindakan' => $this->db->escape_str($this->input->post('tindakan')),
                    'resep' => $resep,
                    'usrent' => fUser('usrname'),
                    'tglent' => date('Y-m-d', time())
                );
                $this->db->insert('tb_pemeriksaan', $datadb);
                redirect(base_url() . 'index.php/pasien');
                break;

            default :
                $dt['id'] = $pilih;
                $dt['judul'] = 'Pasien An. ';
                $dt['aksi'] = base_url() . 'index.php/pasien/periksa/simpan';
                $dt['edit'] = base_url() . 'index.php/pasien/periksa/edit/';

                $this->db->select('*', false);
                $this->db->where("id_pasien = '$pilih'");
                $this->db->order_by('tgl_periksa', 'desc');
                $dt['dtperiksa'] = $this->db->get('tb_pemeriksaan');
                $this->template->load('template/general_temp', 'pemeriksaan/form_pemeriksaan', $dt);
        }
    }

}
