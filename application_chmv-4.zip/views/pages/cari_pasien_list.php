<?php
$pencarian = $this->db->escape_str($this->input->post('entername')) ? $this->db->escape_str($this->input->post('entername')) : '';
?>
<p>&nbsp;</p>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><b><i class="fa fa-group fa-fw"></i>Pencarian Pasien <?= $pencarian; ?></b>
                <div class="pull-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" onclick="printDiv('printArea')">Cetak</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-body">
            <div class="row" id="printArea">
                <div class="col-lg-12">
                    <div class="dataTable_wrapper">
                        <table class="table table-striped table-bordered"  style="font-size: 0.8em;">
                            <thead>
                                <tr>
                                    <th rowspan="2">Nama</th>
                                    <th rowspan="2">NIK</th>
                                    <th rowspan="2">Tempat Tgl. Lahir<br>Umur</th>
                                    <th rowspan="2">Alamat</th>
                                    <th rowspan="2">Riwayat Kontak</th>
                                    <th rowspan="2">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($dtlist->num_rows() > 0) {
                                    foreach ($dtlist->result() as $xdt) {
//                                        $hari = date('d', time());
//                                        $peny = fListRiwayatPenyakit($xdt->id);
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?= $xdt->pasien_nama; ?></td>
                                            <td><?= $xdt->nik; ?></td>
                                            <td><?= $xdt->tmp_lahir; ?>/ <?= date('d-m-Y', strtotime($xdt->tgl_lahir)); ?>
                                                <br><?= hitung_umur($xdt->tgl_lahir); ?></td>
                                            <td><?= $xdt->alamat; ?></td>
                                            <td><?php
                                                foreach (fTbPenyakit()->result() as $idp) {
                                                    $ketemu = fKetemu($xdt->id, $idp->id);
                                                    if ($ketemu != '---') {
                                                        echo tgl($ketemu) . ' ' . fTbPenyakit($idp->id) . '<br>';
                                                    }
                                                }
                                                ?></td>
                                            <td><?= fTbUnor($xdt->id_unor); ?></td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


