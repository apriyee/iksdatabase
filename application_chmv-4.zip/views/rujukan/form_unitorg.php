<?php
$rows = isset($dtEdit) ? $dtEdit->row() : array();
$usr_fullname = isset($dtEdit) ? $rows->unor_name : '';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><?= $judul; ?></div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <form role="form" method="POST" action="<?= $aksi; ?>">
                            <div class="form-group">
                                <label>Nama Unit Organisasi</label>
                                <input class="form-control" name="unor_name" id="unor_name"
                                       autocomplete="off"
                                       value="<?= $usr_fullname; ?>">
                                <p class="help-block">Isikan Nama unit organisasi.</p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-6 (nested) -->
            </div>
        </div>
    </div>
</div>