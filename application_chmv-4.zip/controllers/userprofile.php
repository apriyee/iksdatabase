<?php

class Userprofile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (fUser('usrrole') == "") {
            redirect(base_url());
        }
    }

    public function index() {
        $this->profiles();
    }

    function profiles($aksi = '') {
        $uid = fUser('usrid');
        if ($aksi != '') {
            if ($this->input->post('usr_passw') != '1234567890') {
                $datadb = array(
                    'usr_fullname' => $this->db->escape_str($this->input->post('usr_fullname')),
                    'usr_name' => seo_title($this->input->post('usr_name')),
                    'usr_passw' => md5($this->input->post('usr_passw')),
                    'usr_unit' => $this->input->post('usr_unit')
                );
            } else {
                $datadb = array(
                    'usr_fullname' => $this->db->escape_str($this->input->post('usr_fullname')),
                    'usr_name' => seo_title($this->input->post('usr_name')),
                    'usr_unit' => $this->input->post('usr_unit')
                );
            }
            $this->db->where("id", $uid);
            $this->db->update('tbl_pengguna', $datadb);
            redirect(base_url());
        }
        
        $dt['judul'] = 'Pengguna ' . APPNAME;
        $dt['aksi'] = base_url() . 'index.php/userprofile/profiles/update';
        $dt['dtEdit'] = $this->db->get_where('tbl_pengguna', "id = '$uid'");
        $this->template->load('template/general_temp', 'rujukan/form_pengguna', $dt);
    }

}
